import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/kanban_provider.dart';
import '../models/models.dart';
import '../widgets/kanban_column_widget.dart';
import '../widgets/skeleton_widgets.dart';

class KanbanBoardView extends ConsumerStatefulWidget {
  final KanbanConfig config;

  const KanbanBoardView({
    Key? key,
    this.config = const KanbanConfig(),
  }) : super(key: key);

  @override
  ConsumerState<KanbanBoardView> createState() => _KanbanBoardViewState();
}

class _KanbanBoardViewState extends ConsumerState<KanbanBoardView> {
  late ScrollController _scrollController;
  Timer? _scrollTimer;
  double _currentPointerX = 0;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _scrollTimer?.cancel();
    super.dispose();
  }

  void _startAutoScroll() {
    _scrollTimer?.cancel();
    _scrollTimer = Timer.periodic(const Duration(milliseconds: 16), (timer) {
      if (!mounted) return;
      final screenWidth = MediaQuery.of(context).size.width;
      const threshold = 80.0;
      const scrollSpeed = 8.0;

      if (_currentPointerX < threshold) {
        // Scroll left
        final newOffset = _scrollController.offset - scrollSpeed;
        _scrollController.jumpTo(
            newOffset.clamp(0, _scrollController.position.maxScrollExtent));
      } else if (_currentPointerX > screenWidth - threshold) {
        // Scroll right
        final newOffset = _scrollController.offset + scrollSpeed;
        _scrollController.jumpTo(
            newOffset.clamp(0, _scrollController.position.maxScrollExtent));
      }
    });
  }

  void _stopAutoScroll() {
    _scrollTimer?.cancel();
    _scrollTimer = null;
  }

  @override
  Widget build(BuildContext context) {
    final boardState = ref.watch(kanbanBoardProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFC),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Container(
          height: 44,
          decoration: BoxDecoration(
            color: const Color(0xFFF4F7F9),
            borderRadius: BorderRadius.circular(22),
          ),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Search tasks...',
              hintStyle: TextStyle(color: Color(0xFF9094A6), fontSize: 14),
              border: InputBorder.none,
              prefixIcon:
                  Icon(Icons.search, color: Color(0xFF9094A6), size: 18),
            ),
            style: const TextStyle(color: Color(0xFF2D3142), fontSize: 14),
            onChanged: (val) =>
                ref.read(kanbanBoardProvider.notifier).updateSearchQuery(val),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF4F5D75)),
            onPressed: () {
              // Trigger refresh logic
            },
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF9FAFC), Color(0xFFE8F1FF)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Listener(
          onPointerMove: (event) {
            if (boardState.isDragging) {
              _currentPointerX = event.position.dx;
              if (_scrollTimer == null) _startAutoScroll();
            } else {
              _stopAutoScroll();
            }
          },
          onPointerUp: (_) => _stopAutoScroll(),
          onPointerCancel: (_) => _stopAutoScroll(),
          child: SingleChildScrollView(
            controller: _scrollController,
            scrollDirection: Axis.horizontal,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: boardState.isInitialLoading
                  ? List.generate(4, (index) => const KanbanColumnSkeleton())
                  : boardState.columns.map((column) {
                      return KanbanColumnWidget(
                        column: column,
                        config: widget.config,
                      );
                    }).toList(),
            ),
          ),
        ),
      ),
    );
  }
}
