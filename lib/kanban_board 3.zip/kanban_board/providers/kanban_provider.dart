import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';

class KanbanBoardState {
  final List<KanbanColumn> columns;
  final bool isInitialLoading;
  final String searchQuery;
  final bool isDragging;
  final String? draggingTaskId;
  final String? draggingColumnId;
  final String? hoverColumnId;
  final int? hoverIndex;

  KanbanBoardState({
    this.columns = const [],
    this.isInitialLoading = false,
    this.searchQuery = '',
    this.isDragging = false,
    this.draggingTaskId,
    this.draggingColumnId,
    this.hoverColumnId,
    this.hoverIndex,
  });

  KanbanBoardState copyWith({
    List<KanbanColumn>? columns,
    bool? isInitialLoading,
    String? searchQuery,
    bool? isDragging,
    String? draggingTaskId,
    String? draggingColumnId,
    String? hoverColumnId,
    int? hoverIndex,
    bool clearDragging = false,
    bool clearHover = false,
  }) {
    return KanbanBoardState(
      columns: columns ?? this.columns,
      isInitialLoading: isInitialLoading ?? this.isInitialLoading,
      searchQuery: searchQuery ?? this.searchQuery,
      isDragging: isDragging ?? this.isDragging,
      draggingTaskId: clearDragging
          ? null
          : (draggingTaskId ?? this.draggingTaskId),
      draggingColumnId: clearDragging
          ? null
          : (draggingColumnId ?? this.draggingColumnId),
      hoverColumnId: clearHover ? null : (hoverColumnId ?? this.hoverColumnId),
      hoverIndex: clearHover ? null : (hoverIndex ?? this.hoverIndex),
    );
  }
}

class KanbanBoardNotifier extends StateNotifier<KanbanBoardState> {
  KanbanBoardNotifier() : super(KanbanBoardState(isInitialLoading: true)) {
    _initDemoBoard();
  }

  void setDragging(bool isDragging, {String? taskId, String? columnId}) {
    if (!isDragging) {
      state = state.copyWith(
        isDragging: false,
        clearDragging: true,
        clearHover: true,
      );
    } else {
      state = state.copyWith(
        isDragging: true,
        draggingTaskId: taskId,
        draggingColumnId: columnId,
      );
    }
  }

  void clearHover() {
    state = state.copyWith(clearHover: true);
  }

  void updateHoverPosition(String? columnId, int? index) {
    state = state.copyWith(hoverColumnId: columnId, hoverIndex: index);
  }

  void updateSearchQuery(String query) {
    state = state.copyWith(searchQuery: query);
  }

  void updateTask(String columnId, KanbanTask updatedTask) {
    final columnIndex = state.columns.indexWhere((c) => c.id == columnId);
    if (columnIndex == -1) return;

    final column = state.columns[columnIndex];
    final taskIndex = column.tasks.indexWhere((t) => t.id == updatedTask.id);
    if (taskIndex == -1) return;

    final newTasks = List<KanbanTask>.from(column.tasks);
    newTasks[taskIndex] = updatedTask;

    final newColumns = List<KanbanColumn>.from(state.columns);
    newColumns[columnIndex] = column.copyWith(tasks: newTasks);

    state = state.copyWith(columns: newColumns);
  }

  Future<void> _initDemoBoard() async {
    await Future.delayed(const Duration(seconds: 2));

    state = KanbanBoardState(
      isInitialLoading: false,
      columns: [
        KanbanColumn(
          title: 'To Do',
          colorValue: 0xFFF44336,
          hasMore: true,
          tasks: [
            KanbanTask(
              title: 'Initial Research',
              description: 'Research Kanban architectures',
              dueDate: DateTime.now().add(const Duration(days: 2)),
              tags: ['Research', 'Planning'],
              assignee: 'Alice',
            ),
            KanbanTask(
              title: 'Define Models',
              description: 'Create Task and Column models',
              dueDate: DateTime.now().add(const Duration(days: 1)),
              priority: TaskPriority.high,
              tags: ['Core'],
              assignee: 'Bob',
            ),
          ],
        ),
        KanbanColumn(
          title: 'Build',
          colorValue: 0xFF2196F3,
          hasMore: false,
          tasks: [
            KanbanTask(
              title: 'Architecture Setup',
              description: 'Setup Riverpod and project structure',
              dueDate: DateTime.now(),
              priority: TaskPriority.high,
              tags: ['Infra'],
              assignee: 'Charlie',
            ),
          ],
        ),
        KanbanColumn(
          title: 'Solution Drafting',
          colorValue: 0xFFFF9800,
          hasMore: false,
          tasks: [],
        ),
        KanbanColumn(
          title: 'UAT / UX',
          colorValue: 0xFF4CAF50,
          hasMore: false,
          tasks: [],
        ),
      ],
    );
  }

  Future<void> loadMore(String columnId) async {
    final columnIndex = state.columns.indexWhere((c) => c.id == columnId);
    if (columnIndex == -1 || state.columns[columnIndex].isLoading) return;

    final newColumns = List<KanbanColumn>.from(state.columns);
    newColumns[columnIndex] = newColumns[columnIndex].copyWith(isLoading: true);
    state = state.copyWith(columns: newColumns);

    await Future.delayed(const Duration(seconds: 1));

    final column = state.columns[columnIndex];
    final moreTasks = [
      KanbanTask(
        title: 'New Task ${column.tasks.length + 1}',
        description: 'Automatically loaded more task',
        dueDate: DateTime.now().add(const Duration(days: 3)),
      ),
      KanbanTask(
        title: 'New Task ${column.tasks.length + 2}',
        description: 'Successfully loaded',
        dueDate: DateTime.now().add(const Duration(days: 4)),
      ),
    ];

    final updatedColumns = List<KanbanColumn>.from(state.columns);
    updatedColumns[columnIndex] = column.copyWith(
      tasks: [...column.tasks, ...moreTasks],
      isLoading: false,
      hasMore: column.tasks.length < 10,
    );

    state = state.copyWith(columns: updatedColumns);
  }

  void moveTask(
    String taskId,
    String fromColumnId,
    String toColumnId,
    int toIndex,
  ) {
    if (fromColumnId == toColumnId) {
      _reorderTask(fromColumnId, taskId, toIndex);
      return;
    }

    final fromColumnIndex = state.columns.indexWhere(
      (c) => c.id == fromColumnId,
    );
    final toColumnIndex = state.columns.indexWhere((c) => c.id == toColumnId);

    if (fromColumnIndex == -1 || toColumnIndex == -1) return;

    final fromColumn = state.columns[fromColumnIndex];
    final toColumn = state.columns[toColumnIndex];

    final taskIndex = fromColumn.tasks.indexWhere((t) => t.id == taskId);
    if (taskIndex == -1) return;

    final task = fromColumn.tasks[taskIndex];

    final newFromTasks = List<KanbanTask>.from(fromColumn.tasks)
      ..removeAt(taskIndex);
    final newToTasks = List<KanbanTask>.from(toColumn.tasks)
      ..insert(toIndex, task);

    final newColumns = List<KanbanColumn>.from(state.columns);
    newColumns[fromColumnIndex] = fromColumn.copyWith(tasks: newFromTasks);
    newColumns[toColumnIndex] = toColumn.copyWith(tasks: newToTasks);

    state = state.copyWith(
      columns: newColumns,
      isDragging: false,
      clearDragging: true,
      clearHover: true,
    );
  }

  void _reorderTask(String columnId, String taskId, int toIndex) {
    final columnIndex = state.columns.indexWhere((c) => c.id == columnId);
    if (columnIndex == -1) return;

    final column = state.columns[columnIndex];
    final fromIndex = column.tasks.indexWhere((t) => t.id == taskId);
    if (fromIndex == -1 || fromIndex == toIndex) {
      state = state.copyWith(
        isDragging: false,
        clearDragging: true,
        clearHover: true,
      );
      return;
    }

    final newTasks = List<KanbanTask>.from(column.tasks);
    final task = newTasks.removeAt(fromIndex);

    int actualToIndex = toIndex;
    if (actualToIndex > fromIndex) actualToIndex--;
    actualToIndex = actualToIndex.clamp(0, newTasks.length);

    newTasks.insert(actualToIndex, task);

    final newColumns = List<KanbanColumn>.from(state.columns);
    newColumns[columnIndex] = column.copyWith(tasks: newTasks);

    state = state.copyWith(
      columns: newColumns,
      isDragging: false,
      clearDragging: true,
      clearHover: true,
    );
  }
}

final kanbanBoardProvider =
    StateNotifierProvider<KanbanBoardNotifier, KanbanBoardState>((ref) {
      return KanbanBoardNotifier();
    });
